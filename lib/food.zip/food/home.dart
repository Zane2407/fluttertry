import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fluttertry/food/about_us.dart';
import 'package:fluttertry/food/menu.dart';
import 'font_size_provider.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int _navIndex = 0;
  bool isDarkMode = false;

  final List<Widget> _pages = [
    HomeContent(),
    MenuScreen(),
    Center(child: Text('Cart Page')),
    AboutUs(),
  ];

  @override
  Widget build(BuildContext context) {
    _pages[3] = AboutUs();
    return ChangeNotifierProvider(
      create: (_) => FontSizeProvider(),
      child: MaterialApp(
        theme: isDarkMode
            ? ThemeData.dark().copyWith(
                scaffoldBackgroundColor: Colors.black,
                appBarTheme: const AppBarTheme(backgroundColor: Colors.black),
                bottomNavigationBarTheme: const BottomNavigationBarThemeData(backgroundColor: Colors.black),
              )
            : ThemeData.light(),
        home: Scaffold(
          backgroundColor: isDarkMode ? Colors.black : Colors.pink[50],
          appBar: AppBar(
            leading: Builder(
              builder: (context) => IconButton(
                icon: Icon(Icons.menu, color: isDarkMode ? Colors.white : Colors.black87),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
            ),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      "One Food",
                      style: TextStyle(
                        color: isDarkMode ? Colors.white : Colors.black87,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.nightlight_round, color: isDarkMode ? Colors.white : Colors.black87),
                onPressed: () {
                  setState(() {
                    isDarkMode = !isDarkMode;
                  });
                },
              ),
            ],
            backgroundColor: isDarkMode ? Colors.black : const Color.fromARGB(255, 255, 255, 255),
            elevation: 0,
            iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
          ),
          drawer: Consumer<FontSizeProvider>(
            builder: (context, fontSizeProvider, child) {
              return Drawer(
                backgroundColor: isDarkMode ? Colors.black : Colors.grey[200],
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    UserAccountsDrawerHeader(
                      accountName: Text(
                        "John Doe",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      accountEmail: Text(
                        "john.doe@example.com",
                        style: TextStyle(
                          color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                      currentAccountPicture: CircleAvatar(
                        radius: 40,
                        backgroundImage: AssetImage('images/profile.jpg'),
                        backgroundColor: isDarkMode ? Colors.grey[800] : Colors.white,
                        onBackgroundImageError: (error, stackTrace) => Icon(
                          Icons.person,
                          color: isDarkMode ? Colors.white : Colors.black,
                          size: 40,
                        ),
                      ),
                      decoration: BoxDecoration(
                        color: isDarkMode ? Colors.grey[900] : Colors.pink[100],
                        border: Border(
                          bottom: BorderSide(
                            color: isDarkMode ? Colors.grey[700]! : Colors.grey[400]!,
                          ),
                        ),
                      ),
                    ),
                    ListTile(
                      leading: Icon(Icons.home, color: isDarkMode ? Colors.white : Colors.black),
                      title: Text(
                        "Home",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          _navIndex = 0;
                          Navigator.pop(context);
                        });
                      },
                      selected: _navIndex == 0,
                      selectedTileColor: isDarkMode ? Colors.grey[800] : Colors.pink[50],
                    ),
                    ListTile(
                      leading: Icon(Icons.menu_book, color: isDarkMode ? Colors.white : Colors.black),
                      title: Text(
                        "Menu",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          _navIndex = 1;
                          Navigator.pop(context);
                        });
                      },
                      selected: _navIndex == 1,
                      selectedTileColor: isDarkMode ? Colors.grey[800] : Colors.pink[50],
                    ),
                    ListTile(
                      leading: Icon(Icons.shopping_cart_outlined, color: isDarkMode ? Colors.white : Colors.black),
                      title: Text(
                        "Cart",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          _navIndex = 2;
                          Navigator.pop(context);
                        });
                      },
                      selected: _navIndex == 2,
                      selectedTileColor: isDarkMode ? Colors.grey[800] : Colors.pink[50],
                    ),
                    ListTile(
                      leading: Icon(Icons.settings, color: isDarkMode ? Colors.white : Colors.black),
                      title: Text(
                        "Settings",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        // Add Settings page navigation if implemented
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.info, color: isDarkMode ? Colors.white : Colors.black),
                      title: Text(
                        "About Us",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          _navIndex = 3;
                          Navigator.pop(context);
                        });
                      },
                      selected: _navIndex == 3,
                      selectedTileColor: isDarkMode ? Colors.grey[800] : Colors.pink[50],
                    ),
                    Divider(
                      color: isDarkMode ? Colors.grey[700] : Colors.grey[400],
                      thickness: 1,
                      indent: 16,
                      endIndent: 16,
                    ),
                  
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.remove_circle_outline,
                              color: fontSizeProvider.fontSize <= 12.0
                                  ? (isDarkMode ? Colors.grey[600] : Colors.grey[400])
                                  : (isDarkMode ? Colors.white : Colors.black),
                              size: 32,
                            ),
                            onPressed: fontSizeProvider.fontSize <= 12.0
                                ? null
                                : () {
                                    fontSizeProvider.setFontSize(fontSizeProvider.fontSize - 2.0);
                                  },
                            tooltip: 'Decrease font size',
                          ),
                          SizedBox(width: 12),
                          IconButton(
                            icon: Icon(
                              Icons.add_circle_outline,
                              color: fontSizeProvider.fontSize >= 20.0
                                  ? (isDarkMode ? Colors.grey[600] : Colors.grey[400])
                                  : (isDarkMode ? Colors.white : Colors.black),
                              size: 32,
                            ),
                            onPressed: fontSizeProvider.fontSize >= 20.0
                                ? null
                                : () {
                                    fontSizeProvider.setFontSize(fontSizeProvider.fontSize + 2.0);
                                  },
                            tooltip: 'Increase font size',
                          ),
                          SizedBox(width: 16),
                          Text(
                            '${fontSizeProvider.fontSize.toInt()} px',
                            style: TextStyle(
                              color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Spacer(),
                          IconButton(
                            icon: Icon(
                              Icons.refresh,
                              color: isDarkMode ? Colors.white : Colors.black,
                              size: 32,
                            ),
                            onPressed: () {
                              fontSizeProvider.resetFontSize();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Font size reset to 16 px')),
                              );
                            },
                            tooltip: 'Reset font size',
                          ),
                        ],
                      ),
                    ),
                ],
                ),
              );
            },
          ),
          body: _pages[_navIndex],
          bottomNavigationBar: _buildBottomNavBar(),
        ),
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return BottomNavigationBar(
      currentIndex: _navIndex,
      onTap: (index) {
        setState(() {
          _navIndex = index;
        });
      },
      selectedItemColor: isDarkMode ? Colors.white : const Color.fromARGB(255, 255, 0, 0),
      unselectedItemColor: isDarkMode ? Colors.grey[400] : const Color.fromARGB(255, 119, 116, 116),
      backgroundColor: isDarkMode ? Colors.black : Colors.white,
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: "Menu"),
        BottomNavigationBarItem(icon: Icon(Icons.shopping_cart_outlined), label: "Cart"),
        BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "About Us"),
      ],
    );
  }
}

class HomeContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 10),
          Container(
            height: 45,
            width: double.infinity,
            decoration: BoxDecoration(
              color: isDarkMode ? Colors.black : Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: isDarkMode ? Colors.black12 : Color.fromARGB(255, 5, 5, 5),
                  blurRadius: 1,
                )
              ],
            ),
            child: Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: Icon(Icons.search, color: isDarkMode ? Colors.white : Colors.black),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    style: TextStyle(color: isDarkMode ? Colors.white : Colors.black),
                    decoration: InputDecoration(
                      hintText: "Search",
                      hintStyle: TextStyle(color: isDarkMode ? Colors.grey[400] : Colors.grey),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 15),
          Container(
            height: 120,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              image: DecorationImage(
                image: AssetImage('images/Food-Banner.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[900] : const Color.fromARGB(255, 255, 131, 22),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: isDarkMode ? Colors.black12 : Color.fromARGB(255, 5, 5, 5),
                          blurRadius: 1,
                        )
                      ],
                    ),
                    child: Icon(Icons.food_bank, color: isDarkMode ? Colors.white : const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  Center(
                    child: Text(
                      'Food',
                      style: TextStyle(fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[900] : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: isDarkMode ? Colors.black12 : Color.fromARGB(255, 5, 5, 5),
                          blurRadius: 1,
                        )
                      ],
                    ),
                    child: Icon(Icons.local_pizza, color: isDarkMode ? Colors.white : const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  Center(
                    child: Text(
                      'Pizza',
                      style: TextStyle(fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[900] : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: isDarkMode ? Colors.black12 : Color.fromARGB(255, 5, 5, 5),
                          blurRadius: 1,
                        )
                      ],
                    ),
                    child: Icon(Icons.icecream, color: isDarkMode ? Colors.white : const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  Center(
                    child: Text(
                      'Dessert',
                      style: TextStyle(fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[900] : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: isDarkMode ? Colors.black12 : Color.fromARGB(255, 5, 5, 5),
                          blurRadius: 1,
                        )
                      ],
                    ),
                    child: Icon(Icons.local_cafe, color: isDarkMode ? Colors.white : Colors.black),
                  ),
                  Center(
                    child: Text(
                      'Cafe',
                      style: TextStyle(fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[900] : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: isDarkMode ? Colors.black12 : Color.fromARGB(255, 5, 5, 5),
                          blurRadius: 1,
                        )
                      ],
                    ),
                    child: Icon(Icons.local_drink, color: isDarkMode ? Colors.white : const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  Center(
                    child: Text(
                      'Drinks',
                      style: TextStyle(fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black),
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 10),
          Row(
            children: [
              Text(
                'Popular',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: isDarkMode ? Colors.white : Colors.black),
              ),
            ],
          ),
          SizedBox(height: 10),
          Expanded(
            child: ListView(
              children: [
                SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: 3,
                    separatorBuilder: (context, index) => SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      return Container(
                        height: 80,
                        width: 350,
                        margin: EdgeInsets.only(left: 10),
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.black : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: isDarkMode ? Colors.black26 : Colors.grey.withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset(
                                  'images/p.jpg',
                                  height: 64,
                                  width: 64,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Cheese Burger',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isDarkMode ? Colors.white : Colors.black,
                                      ),
                                    ),
                                    Text(
                                      '250g (1 pcs)',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                        fontSize: 12,
                                      ),
                                    ),
                                    Text(
                                      '\$7',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.white70 : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Icon(
                                    Icons.favorite,
                                    color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                    size: 25,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 10),
                SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: 3,
                    separatorBuilder: (context, index) => SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      return Container(
                        height: 80,
                        width: 350,
                        margin: EdgeInsets.only(left: 10),
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.black : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: isDarkMode ? Colors.black26 : Colors.grey.withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset(
                                  'images/p.jpg',
                                  height: 64,
                                  width: 64,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Spicy Pasta',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isDarkMode ? Colors.white : Colors.black,
                                      ),
                                    ),
                                    Text(
                                      '200g (1 pcs)',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                        fontSize: 12,
                                      ),
                                    ),
                                    Text(
                                      '\$8',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.white70 : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Icon(
                                    Icons.favorite,
                                    color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                    size: 25,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 10),
                SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: 3,
                    separatorBuilder: (context, index) => SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      return Container(
                        height: 80,
                        width: 350,
                        margin: EdgeInsets.only(left: 10),
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.black : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: isDarkMode ? Colors.black26 : Colors.grey.withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset(
                                  'images/p.jpg',
                                  height: 64,
                                  width: 64,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Special Pizza',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isDarkMode ? Colors.white : Colors.black,
                                      ),
                                    ),
                                    Text(
                                      '300g (1 pcs)',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                        fontSize: 12,
                                      ),
                                    ),
                                    Text(
                                      '\$9',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.white70 : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Icon(
                                    Icons.favorite,
                                    color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                    size: 25,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 10),
                SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: 3,
                    separatorBuilder: (context, index) => SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      return Container(
                        height: 80,
                        width: 350,
                        margin: EdgeInsets.only(left: 10),
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.black : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: isDarkMode ? Colors.black26 : Colors.grey.withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset(
                                  'images/p.jpg',
                                  height: 64,
                                  width: 64,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Chicken Biriyani',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isDarkMode ? Colors.white : Colors.black,
                                      ),
                                    ),
                                    Text(
                                      '350g (1 pcs)',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                        fontSize: 12,
                                      ),
                                    ),
                                    Text(
                                      '\$10',
                                      style: TextStyle(
                                        color: isDarkMode ? Colors.white70 : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Icon(
                                    Icons.favorite,
                                    color: isDarkMode ? Colors.orange[200] : Colors.orange,
                                    size: 25,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}